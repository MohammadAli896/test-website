function changeImage1()
{
  var img = document.getElementById("image-window");
  img.setAttribute('src', 'images/1.jpg')
}
function changeImage2()
{
  var img = document.getElementById("image-window");
  img.setAttribute('src', 'images/2.jpg')
}
function changeImage3()
{
  var img = document.getElementById("image-window");
  img.setAttribute('src', 'images/3.jpg')
}
function changeImage4()
{
  var img = document.getElementById("image-window");
  img.setAttribute('src', 'images/4.jpg')
}
function changeImage5()
{
  var img = document.getElementById("image-window");
  img.setAttribute('src', 'images/5.jpg')
}
function changeImage6()
{
  var img = document.getElementById("image-window");
  img.setAttribute('src', 'images/6.jpg')
}
function changeImage7()
{
  var img = document.getElementById("image-window");
  img.setAttribute('src', 'images/7.jpg')
}
function changeImage8()
{
  var img = document.getElementById("image-window");
  img.setAttribute('src', 'images/8.jpg')
}
function changeImage9()
{
  var img = document.getElementById("image-window");
  img.setAttribute('src', 'images/9.jpg')
}
function changeImage10()
{
  var img = document.getElementById("image-window");
  img.setAttribute('src', 'images/10.jpg')
}